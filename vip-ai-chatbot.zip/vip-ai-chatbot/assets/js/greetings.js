jQuery(document).ready(function ($) {
    localStorage.setItem('chatgpt_initial_greeting', greetings_data.initial_greeting);
    localStorage.setItem('chatgpt_subsequent_greeting', greetings_data.subsequent_greeting);
});